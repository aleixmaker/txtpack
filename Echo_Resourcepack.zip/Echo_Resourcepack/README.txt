ECHO RESOURCE PACK - SETUP INSTRUCTIONS
========================================

FOLDER STRUCTURE:
Echo_Resourcepack/
├── pack.mcmeta
├── pack.png              ← (optional) add your own 64x64 pack icon here
└── assets/
    └── minecraft/
        ├── models/
        │   └── item/
        │       ├── chest.json          ← overrides Chest item
        │       ├── nether_star.json    ← overrides Nether Star item
        │       └── echo/
        │           ├── swapper.json    ← Swapper model
        │           └── upgrader.json   ← Upgrader model
        └── textures/
            └── item/
                └── echo/
                    ├── swapper.png     ← PUT YOUR SWAPPER TEXTURE HERE
                    └── upgrader.png    ← PUT YOUR UPGRADER TEXTURE HERE

WHAT TO DO:
1. Drop your Swapper texture into:
   assets/minecraft/textures/item/echo/swapper.png

2. Drop your Upgrader texture into:
   assets/minecraft/textures/item/echo/upgrader.png

3. Textures MUST be .png format and ideally 16x16 or 32x32 pixels.
   If your textures are larger (e.g. 1024x1024), resize them to 16x16 or 32x32
   for best results in-game. Minecraft scales them down anyway.

4. Zip the entire Echo_Resourcepack folder into Echo_Resourcepack.zip

5. Put the zip in your server's resource-packs folder or upload it somewhere
   and link it in server.properties under resource-pack=

CUSTOM MODEL DATA VALUES (used by the plugin):
- Swapper  (CHEST item)       = custom model data 1001
- Upgrader (NETHER_STAR item) = custom model data 1002

These match exactly what the patched ItemManager.java sets.
All other Chest and Nether Star items in the game are unaffected.
